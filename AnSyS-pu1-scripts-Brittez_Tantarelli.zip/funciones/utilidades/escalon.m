function h = escalon(t)
    % TRI1 se~nal del ejercicio 2 de la Pr ́actica 1
    h = (1).*(t >= 0);
end
