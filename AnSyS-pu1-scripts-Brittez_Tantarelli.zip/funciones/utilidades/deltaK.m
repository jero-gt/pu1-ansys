function h = deltaK(n)
    h = (1).*(n == 0);
end
