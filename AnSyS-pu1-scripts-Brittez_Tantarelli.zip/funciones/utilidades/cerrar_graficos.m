function cerrar_graficos
input('');
close all;
end
